﻿namespace WvW_Status
{
    public class WorldsList
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public string Population { get; set; }
    }
}